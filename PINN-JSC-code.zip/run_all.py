from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent/'scripts'
for name in ['01_residual_sampling_stress.py','02_cost_phase_map.py','03_generalization_operator.py','04_rollout_stability_map.py','05_hybrid_mesh_stability.py','06_sensor_information_study.py','07_publication_figures.py']:
    print(f'\n=== {name} ===', flush=True)
    subprocess.run([sys.executable,str(root/name)],check=True)
print('\nAll simulations completed.')
