"""Replot all five manuscript figures from the saved experiment results.

The numerical data and model predictions are produced by scripts 01--06.  This
module ONLY changes presentation: panel layout, typography and legends for the
narrow JSC text column. It does not train a network or alter an experiment.
"""
from pathlib import Path
import json
import shutil
import subprocess
import warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors

OUT = Path(__file__).resolve().parents[1] / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({
    'font.family':'DejaVu Sans', 'font.size':12.1,
    'axes.labelsize':12.1, 'axes.titlesize':12.1,
    'xtick.labelsize':10.9, 'ytick.labelsize':10.9,
    'legend.fontsize':10.5, 'lines.linewidth':1.75,
    'axes.linewidth':0.8, 'savefig.dpi':240,
})

def save(fig, name):
    # The PDF is the authoritative vector rendering. Matplotlib's EPS backend
    # drops transparency, altering colors and line overlays in some panels.
    pdf = OUT / f'{name}.pdf'
    fig.savefig(pdf, dpi=240, bbox_inches='tight', pad_inches=0.12)
    fig.savefig(OUT / f'{name}.png', dpi=240, bbox_inches='tight', pad_inches=0.12)
    eps = OUT / f'{name}.eps'
    converter = shutil.which('pdftocairo')
    if converter:
        subprocess.run([converter, '-eps', str(pdf), str(eps)], check=True)
    else:
        warnings.warn('pdftocairo not installed: EPS may differ from PDF where transparency is used')
        fig.savefig(eps, dpi=240, bbox_inches='tight', pad_inches=0.12)
    plt.close(fig)

def figure1():
    d=json.loads((OUT/'fig1_residual_sampling_stress.json').read_text())
    m=d['m']; a=d['a_demo']
    fig=plt.figure(figsize=(6.55,5.25))
    gs=fig.add_gridspec(2,2, height_ratios=[1.08,1.02],left=.13,right=.96,bottom=.11,top=.94,hspace=.62,wspace=.39)
    ax=fig.add_subplot(gs[0,0]); x=np.linspace(0,1,1000)
    ax.plot(x,a*np.sin(m*np.pi*x),lw=1.5)
    ax.axhline(0,c='0.5',ls='--',lw=1)
    xc=np.arange(1,m)/m; ax.scatter(xc,np.zeros_like(xc),s=23,zorder=5)
    ax.set(xlabel=r'$x$',ylabel='State value',xlim=(0,1))
    ax.set_title('(a) Aliased collocation',loc='left',pad=6)
    ax=fig.add_subplot(gs[0,1]); q=np.array(d['random_sampling_ratios'])
    med=np.array(d['sampling_ratio_median']);lo=np.array(d['sampling_ratio_p05']);hi=np.array(d['sampling_ratio_p95'])
    ax.errorbar(q,med,yerr=np.vstack([med-lo,hi-med]),fmt='o-',capsize=3.5)
    ax.axhline(1,c='0.5',ls='--',lw=1)
    ax.set_xscale('log',base=2)
    ax.set(xlabel=r'Samples/wavelength $N_{\mathrm{r}}/m$',ylabel='RMS ratio')
    ax.grid(axis='y',alpha=.24)
    ax.set_title('(b) Random collocation',loc='left',pad=6)
    ax=fig.add_subplot(gs[1,:]); train=d['training_final_state_error']
    ax.boxplot([train['fixed'],train['jittered'],train['resampled']],tick_labels=['Fixed aliased','Fixed jittered','Resampled'],widths=.38,showfliers=True)
    ax.set_yscale('log');ax.set_ylabel(r'Final field error $E_2$')
    ax.set_ylim(5e-16,1.5)
    ax.set_title('(c) Scalar-amplitude optimization',loc='left',pad=7)
    ax.grid(axis='y',alpha=.23)
    save(fig,'fig1_residual_sampling_stress')

def figure2():
    fig=plt.figure(figsize=(6.55,6.35))
    gs=fig.add_gridspec(2,1,left=.13,right=.87,bottom=.08,top=.91,hspace=.56)
    ax=fig.add_subplot(gs[0]); b=np.linspace(0,.98,300)
    for a,ls in zip([.1,1,10,100,1000],['-','--','-.',':',(0,(5,2,1,2))]):
        ax.plot(b,a/(1-b),ls=ls,label=fr'$\alpha={a:g}$')
    ax.set(yscale='log',xlabel=r'Online-cost ratio $\beta$',ylabel=r'Break-even queries $Q_\star$',xlim=(0,1))
    ax.grid(alpha=.2)
    ax.set_title('(a) Dependence on offline cost',loc='left',pad=7)
    ax.legend(loc='lower right',ncol=3,fontsize=10,framealpha=.86,handlelength=2)
    ax=fig.add_subplot(gs[1]); B=np.linspace(0,1.2,241);A=np.logspace(-1,3,241)
    BB,AA=np.meshgrid(B,A)
    with np.errstate(divide='ignore',invalid='ignore'):
        Q=np.where(BB<1,AA/(1-BB),np.nan)
    cf=ax.contourf(B,A,Q,levels=np.logspace(-1,5,19),cmap='viridis',norm=colors.LogNorm(vmin=.1,vmax=1e5),extend='max')
    ax.axvline(1,c='0.1',ls='--',lw=1)
    ax.axvspan(1,1.2,color='0.9',zorder=0)
    ax.text(1.07,15,'No break-even',rotation=90,ha='center',va='center',fontsize=11)
    ax.set(yscale='log',xlabel=r'Online-cost ratio $\beta$',ylabel=r'Offline-cost ratio $\alpha$',xlim=(0,1.2))
    ax.set_title('(b) Workload regimes',loc='left',pad=7)
    cb=fig.colorbar(cf,ax=ax,pad=.018,fraction=.05)
    cb.ax.set_ylabel(r'$Q_\star$',rotation=90,labelpad=8)
    save(fig,'fig2_break_even_phase')

def figure3():
    original=json.loads((OUT/'fig3_generalization_stress.json').read_text())
    matched=json.loads((OUT/'fig3_sensor_matched_retraining.json').read_text())
    vals=np.asarray(original['per_seed_median_relative_L2'],dtype=float)
    retr=np.asarray(matched['eight_sensor_retrained_median_relative_errors'],dtype=float)
    cmed=float(matched['eight_sensor_gaussian_conditional_mean_median_relative_error'])
    clo,chi=map(float,matched['eight_sensor_gaussian_conditional_mean_median_relative_bootstrap_95pct'])
    fig=plt.figure(figsize=(6.6,5.9))
    gs=fig.add_gridspec(2,1,left=.14,right=.96,bottom=.13,top=.94,hspace=.82)
    ax=fig.add_subplot(gs[0]); x=np.arange(4); med=np.median(vals,axis=0)
    ax.errorbar(x,med,yerr=np.vstack([med-vals.min(0),vals.max(0)-med]),fmt='D',capsize=4,lw=1.4)
    for j in range(len(vals)):ax.plot(x,vals[j],'.',ms=6,alpha=.6)
    ax.set(yscale='log',ylim=(.022,.37),ylabel=r'Median $E_2^{\mathrm{rel}}$')
    ax.set_xticks(x,[r'In-range $\mu$',r'64 $\to$ 256'+'\noutput grid','Eight sensors\ninterpolated',r'Out-of-range $\mu$'])
    ax.tick_params(axis='x',labelsize=10.0)
    ax.grid(axis='y',alpha=.24)
    ax.set_title('(a) Changes in deployment conditions',loc='left',pad=7)
    bx=fig.add_subplot(gs[1]); v=np.vstack([vals[:,2],retr]).T; m=np.median(v,axis=0)
    bx.errorbar([0,1],m,yerr=np.vstack([m-v.min(0),v.max(0)-m]),fmt='D',capsize=4,lw=1.5)
    for j in range(len(v)):bx.plot([0,1],v[j],'.',ms=6,alpha=.6)
    bx.errorbar([2],[cmed],yerr=[[cmed-clo],[chi-cmed]],fmt='s',mfc='none',mew=1.5,capsize=4,ms=7)
    bx.set(yscale='log',ylim=(.009,.36),ylabel=r'Median $E_2^{\mathrm{rel}}$')
    bx.set_xticks([0,1,2],[r'8 $\to$ 32 sensors'+'\ninterpolated','Eight-sensor network\n(retrained)','Gaussian\nconditional mean'])
    bx.tick_params(axis='x',labelsize=10.0)
    bx.grid(axis='y',alpha=.24)
    bx.set_title('(b) Sensor information and protocol',loc='left',pad=7)
    save(fig,'fig3_generalization_stress')

def figure4():
    N=80; nu=.1;h=1/(N+1); k=np.arange(1,N+1)
    lam=-4/h**2*np.sin(k*np.pi/(2*(N+1)))**2
    dt=np.log(.995)/(nu*lam[0]); sig=np.exp(nu*lam*dt)
    eps=np.linspace(0,.08,321);rho=np.maximum(sig[0],sig[:,None]+eps[None,:])
    fig=plt.figure(figsize=(6.55,5.4))
    gs=fig.add_gridspec(2,2,height_ratios=[.9,1.0],left=.13,right=.90,bottom=.11,top=.93,hspace=.58,wspace=.45)
    ax=fig.add_subplot(gs[0,:])
    im=ax.imshow(rho,origin='lower',aspect='auto',extent=[eps[0],eps[-1],1,N],norm=colors.TwoSlopeNorm(vmin=.98,vcenter=1,vmax=1.08),cmap='RdYlBu_r')
    ax.contour(eps,np.arange(1,N+1),rho,levels=[1.],colors='k',linewidths=1)
    ax.set(xlabel=r'Perturbation magnitude $\varepsilon$',ylabel='Perturbed mode')
    ax.set_title('(a) Spectral radius of the perturbed map',loc='left',pad=7)
    ax.set_xticks([0,.02,.04,.06,.08])
    cax=fig.add_axes([.915,.58,.016,.31]); cbar=fig.colorbar(im,cax=cax);cbar.ax.tick_params(labelsize=9)
    cbar.set_label(r'$\rho$',labelpad=3)
    ax=fig.add_subplot(gs[1,0]);ax.plot(k,1-sig,'-',lw=1.7)
    ax.set(yscale='log',xlabel='Mode index',ylabel=r'Critical $\varepsilon_{\mathrm{c}}$')
    ax.set_title('(b) Directional thresholds',loc='left',pad=7);ax.grid(alpha=.22)
    ax=fig.add_subplot(gs[1,1]); e=np.linspace(1e-5,.009,300)
    n=np.ceil(np.log(1.1)/np.log(1+e/sig[0]))
    ax.plot(e,n,lw=1.7);ax.axvline(.005,c='0.35',ls='--',lw=1.2)
    ax.set(yscale='log',xlabel=r'Slow-mode $\varepsilon$',ylabel='Steps to 10% error')
    ax.set_title('(c) Error horizon',loc='left',pad=7);ax.grid(alpha=.22)
    ax.set_xticks([0,.003,.006,.009]);ax.tick_params(axis='x',labelsize=9.5)
    save(fig,'fig4_rollout_stability_map')

def figure5():
    eps=5e-4;Ns=np.arange(10,201,2)
    hs=1/(Ns+1);lm=4/hs**2*np.sin(Ns*np.pi/(2*(Ns+1)))**2
    ll=4/hs**2*np.sin(np.pi/(2*(Ns+1)))**2
    fig=plt.figure(figsize=(6.55,5.55))
    gs=fig.add_gridspec(2,2,left=.13,right=.96,bottom=.11,top=.94,hspace=.60,wspace=.44)
    ax=fig.add_subplot(gs[0,:]); ax.loglog(hs,1/lm,'-',label=r'$1/\lambda_{\max}(\mathbf{A}_h)$')
    ax.loglog(hs,hs**2/4,'--',label=r'$h^2/4$')
    ax.set(xlabel='Mesh spacing $h$',ylabel=r'Critical $\varepsilon_{\mathrm{c}}$')
    ax.set_title('(a) Mesh-dependent threshold',loc='left',pad=7)
    ax.legend(loc='upper left',ncol=2,fontsize=10,framealpha=.8)
    ax.grid(alpha=.2,which='both')
    ax=fig.add_subplot(gs[1,0]);ax.plot(Ns,eps*ll,'-',label='Low mode')
    ax.plot(Ns,eps*lm,'--',label='High mode')
    ax.axhline(1,c='0.4',ls=':',lw=1.1)
    ax.set(yscale='log',xlabel='Interior nodes $N$',ylabel='Coupled spectral radius')
    ax.legend(loc='center right',fontsize=9.5,framealpha=.86)
    ax.set_title('(b) Same component error',loc='left',pad=7)
    ax.grid(alpha=.2)
    ax=fig.add_subplot(gs[1,1]);its=np.arange(11)
    for N,ls in [(20,'-'),(40,'--'),(80,'-.')]:
        h=1/(N+1); high=4/h**2*np.sin(N*np.pi/(2*(N+1)))**2
        amp=eps*high
        ax.plot(its,amp**its,ls=ls,label=f'$N={N}$')
    ax.set(yscale='log',xlabel='Iteration',ylabel='Relative residual',xlim=(0,10))
    ax.legend(loc='upper left',fontsize=9.5,framealpha=.82)
    ax.set_title('(c) Aligned high-mode residual',loc='left',pad=7)
    ax.grid(alpha=.2)
    save(fig,'fig5_hybrid_mesh_stability')

if __name__=='__main__':
    for f in (figure1,figure2,figure3,figure4,figure5):
        f()
    print('Five figures replotted; no numerical datasets changed.')
