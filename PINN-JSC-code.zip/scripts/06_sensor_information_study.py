"""Reproducible sensor-conditional reference and sensor-matched network training.

This script imports the unchanged 32-sensor training setup from script 03, trains an
8-sensor network with the same architecture depth, steps and data budget, and
computes the Gaussian conditional-mean reference using the known forcing prior.
The conditional mean is optimal for expected *squared absolute* field error,
NOT a proven lower bound on per-sample relative field error medians.
"""
from pathlib import Path
import importlib.util, json, time
import numpy as np
import torch
from torch import nn

this = Path(__file__).resolve()
spec = importlib.util.spec_from_file_location('gen_operator', this.parent/'03_generalization_operator.py')
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)

# Use exactly the original fixed 600-function test set and original 5 training seeds.
class MatchedSensorNet(nn.Module):
    def __init__(self, n_sensors):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n_sensors+1,64), nn.Tanh(), nn.Linear(64,64), nn.Tanh(), nn.Linear(64,gen.K))
    def forward(self, x):
        return self.net(x)


def train_one_matched(seed):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    _, S = gen.sensor_matrix(gen.NCOARSE)
    f, mu, u = gen.sample_data(rng,gen.NTRAIN,0.5,2.)
    x = np.concatenate([f@S.T,mu],axis=1).astype(np.float32)
    y = u.astype(np.float32)
    xm=x.mean(0,keepdims=True); xs=x.std(0,keepdims=True)+1e-6
    ym=y.mean(0,keepdims=True); ys=y.std(0,keepdims=True)+1e-7
    X=torch.from_numpy((x-xm)/xs)
    Y=torch.from_numpy((y-ym)/ys)
    net = MatchedSensorNet(gen.NCOARSE)
    opt = torch.optim.Adam(net.parameters(),lr=2e-3)
    sampler=torch.Generator().manual_seed(seed+1000)
    for step in range(gen.STEPS):
        batch=torch.randint(0,gen.NTRAIN,(gen.BATCH,),generator=sampler)
        loss=((net(X[batch])-Y[batch])**2).mean()
        opt.zero_grad();loss.backward();opt.step()
        if step in (900,1200):
            for group in opt.param_groups: group['lr'] *=0.35
    return net,(xm,xs,ym,ys)


def gaussian_conditional_mean(coarse_features, mu):
    _, S = gen.sensor_matrix(gen.NCOARSE)
    # Independent Gaussian modal coefficients with variances 1/s.
    cov = np.diag(1/np.arange(1,gen.K+1,dtype=np.float64))
    gain = np.linalg.solve(S@cov@S.T, S@cov).T  # 12 x 8
    a = coarse_features @ gain.T
    lam = (np.pi*np.arange(1,gen.K+1,dtype=np.float64))**2
    u = a/(lam[None,:]+mu)
    postcov = cov-cov@S.T@np.linalg.solve(S@cov@S.T, S@cov)
    return u, postcov


def main():
    t0=time.time()
    (f,mu,u),_=gen.make_common_test_sets()
    _,Sc=gen.sensor_matrix(gen.NCOARSE)
    coarse=f@Sc.T
    upost,postcov=gaussian_conditional_mean(coarse,mu)
    oracle_errors=gen.rel_l2_from_coeff(upost,u)
    matched=[]
    per_case=[]
    for seed in gen.SEEDS:
        net,norm=train_one_matched(seed)
        pred=gen.predict(net,norm,np.concatenate([coarse,mu],axis=1))
        errors=gen.rel_l2_from_coeff(pred,u)
        matched.append(float(np.median(errors)))
        per_case.append(errors)
    # Deterministic nonparametric bootstrap for test-set sampling variability of
    # the oracle sample median; no simulated training variation for the oracle.
    rboot=np.random.default_rng(20261108)
    draws=rboot.integers(0,gen.NTEST,size=(2000,gen.NTEST))
    medboot=np.median(oracle_errors[draws],axis=1)
    # Conditional expected squared absolute E2 error, for a fixed mu.
    lam=(np.pi*np.arange(1,gen.K+1,dtype=np.float64))**2
    inv=(lam[None,:]+mu)**-1
    expected_E2sq=0.5*np.sum(np.diag(postcov)[None,:]*inv**2,axis=1)
    out={
      'original_protocol_retained': {'train_pairs':gen.NTRAIN,'test_pairs':gen.NTEST,'steps':gen.STEPS,'batch':gen.BATCH,'seeds':gen.SEEDS,'fixed_test_seed':gen.TEST_SEED},
      'eight_sensor_retrained_median_relative_errors': matched,
      'eight_sensor_retrained_across_seed_median':float(np.median(matched)),
      'eight_sensor_retrained_across_seed_range':[float(min(matched)),float(max(matched))],
      'eight_sensor_gaussian_conditional_mean_median_relative_error':float(np.median(oracle_errors)),
      'eight_sensor_gaussian_conditional_mean_median_relative_bootstrap_95pct':[float(v) for v in np.quantile(medboot,[.025,.975])],
      'eight_sensor_gaussian_conditional_mean_mean_relative_error':float(np.mean(oracle_errors)),
      'eight_sensor_gaussian_conditional_mean_mean_squared_absolute_E2':float(np.mean(expected_E2sq)),
      'observed_mean_squared_absolute_E2':float(np.mean(0.5*np.sum((u-upost)**2,axis=1))),
      'sensor_matrix_rank':int(np.linalg.matrix_rank(Sc)),
      'prior_coefficient_dimension':gen.K,
      'posterior_covariance_trace':float(np.trace(postcov)),
      'oracle_scope':'Optimal for expected squared absolute field error under the stated Gaussian prior and noiseless eight-sensor observations; not an error floor for the median relative error',
      'matched_retrained_scope':'Trained on eight sensors from the start; NOT zero-shot adaptation of the original 32-sensor network',
      'runtime_seconds':time.time()-t0
    }
    # Fig. 3 revised with a separate, interpretable sensor-information panel.
    # Panel (a) reproduces the four original comparisons with the original five seeds;
    # panel (b) compares zero-shot sensor coarsening, matched retraining, and a
    # model-based Gaussian conditional estimator on the exact same 600 tests.
    import matplotlib.pyplot as plt
    original=json.loads((gen.OUT/'fig3_generalization_stress.json').read_text())
    val=np.asarray(original['per_seed_median_relative_L2'])
    top=np.median(val,axis=0)
    fig,(ax,bx)=plt.subplots(2,1,figsize=(7.9,6.7),gridspec_kw={'height_ratios':[1,0.94]})
    fig.subplots_adjust(left=.11,right=.94,top=.94,bottom=.12,hspace=.68)
    x=np.arange(4)
    ax.errorbar(x,top,yerr=np.vstack((top-val.min(axis=0),val.max(axis=0)-top)),fmt='D',capsize=5,lw=1.5,label='median and seed range')
    for k in range(val.shape[0]): ax.plot(x,val[k],'o',ms=3,alpha=.45)
    ax.set_yscale('log');ax.set_ylim(.024,.36)
    ax.set_xticks(x,['parameter\nin-range','64→256 output\nevaluation','32→8 sensors\n(no retraining)','parameter\nout-of-range'])
    ax.set_ylabel(r'Median relative $E_2^{\mathrm{rel}}$')
    ax.grid(True,axis='y',alpha=.25)
    ax.set_title('(a) Changes in evaluation conditions',loc='left',fontsize=11)

    sensor_vals=np.array([val[:,2],np.asarray(matched)]).T
    vmed=np.median(sensor_vals,axis=0)
    bx.errorbar([0,1],vmed,yerr=np.vstack([vmed-sensor_vals.min(axis=0),sensor_vals.max(axis=0)-vmed]),fmt='D',capsize=5,lw=1.5,label='five training seeds')
    for j in range(sensor_vals.shape[0]): bx.plot([0,1],sensor_vals[j,:],'o',ms=3,alpha=.45)
    blo,bhi=np.quantile(medboot,[.025,.975]); bmed=np.median(oracle_errors)
    bx.errorbar([2],[bmed],yerr=np.array([[bmed-blo],[bhi-bmed]]),fmt='s',mfc='none',mew=1.5,capsize=5,ms=7,label='conditional mean: test bootstrap')
    bx.set_yscale('log');bx.set_ylim(.008,.36)
    bx.set_xticks([0,1,2],['8→32 sensor\ninterpolation','8-sensor network\n(retrained)','Gaussian\nconditional mean'])
    bx.set_ylabel(r'Median relative $E_2^{\mathrm{rel}}$')
    bx.set_title('(b) Information loss versus model/protocol error',loc='left',fontsize=11)
    bx.grid(True,axis='y',alpha=.25)
    for ext in ('pdf','eps','png'):
        fig.savefig(gen.OUT/f'fig3_generalization_stress.{ext}',dpi=250)
    plt.close(fig)
    path=gen.OUT/'fig3_sensor_matched_retraining.json'
    path.write_text(json.dumps(out,indent=2))
    (gen.OUT/'fig3_sensor_matched_retraining_per_case.npz').write_bytes(b'') if False else None
    print(json.dumps(out,indent=2))

if __name__=='__main__':
    torch.set_num_threads(1)
    main()
