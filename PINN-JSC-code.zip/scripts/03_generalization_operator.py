from pathlib import Path
import json, time
import numpy as np
import torch
from torch import nn
import matplotlib.pyplot as plt

FIG_FONT = 11.2  # gives about 9 pt after full-width placement in the JSC smallextended text block
plt.rcParams.update({
    'font.size': FIG_FONT,
    'axes.labelsize': FIG_FONT,
    'xtick.labelsize': FIG_FONT,
    'ytick.labelsize': FIG_FONT,
    'legend.fontsize': FIG_FONT,
})

OUT = Path(__file__).resolve().parents[1] / 'figures'
OUT.mkdir(parents=True, exist_ok=True)
SEEDS = [11, 23, 37, 53, 71]
K = 12
NS = 32
NCOARSE = 8
NTRAIN = 4000
NTEST = 600
TEST_SEED = 20261105
STEPS = 1400
BATCH = 256

# Deterministic synthetic operator: -u'' + mu u = f on (0,1), u(0)=u(1)=0.
# f and u are represented in the sine eigenbasis.
def sensor_matrix(n):
    x = np.linspace(0,1,n+2,dtype=np.float64)[1:-1]
    k = np.arange(1,K+1,dtype=np.float64)
    return x, np.sin(np.pi*np.outer(x,k))

def sample_data(rng, n, mu_lo, mu_hi):
    # decreasing modal amplitudes keep the fields smooth but retain resolvable high frequencies
    scale = 1.0 / np.sqrt(np.arange(1,K+1,dtype=np.float64))
    fcoef = rng.normal(size=(n,K))*scale
    mu = rng.uniform(mu_lo, mu_hi, size=(n,1))
    lam = (np.pi*np.arange(1,K+1,dtype=np.float64))**2
    ucoef = fcoef/(lam[None,:] + mu)
    return fcoef, mu, ucoef

def rel_l2_from_coeff(pred, true):
    # sine basis is L2-orthogonal with common factor 1/2, which cancels in the ratio
    return np.linalg.norm(pred-true,axis=1)/(np.linalg.norm(true,axis=1)+1e-14)

def rel_l2_on_grid(pred, true, ngrid):
    x = np.linspace(0,1,ngrid+2,dtype=np.float64)[1:-1]
    S = np.sin(np.pi*np.outer(x,np.arange(1,K+1,dtype=np.float64)))
    up = pred@S.T
    ut = true@S.T
    return np.linalg.norm(up-ut,axis=1)/(np.linalg.norm(ut,axis=1)+1e-14)

class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(NS+1,64), nn.Tanh(), nn.Linear(64,64), nn.Tanh(), nn.Linear(64,K))
    def forward(self,x): return self.net(x)

def train_one(seed):
    np_rng=np.random.default_rng(seed)
    torch.manual_seed(seed)
    xs,Ss=sensor_matrix(NS)
    ftr, mutr, utr = sample_data(np_rng,NTRAIN,0.5,2.0)
    xtr=np.concatenate([ftr@Ss.T, mutr],axis=1).astype(np.float32)
    ytr=utr.astype(np.float32)
    xm=xtr.mean(0,keepdims=True); xscl=xtr.std(0,keepdims=True)+1e-6
    ym=ytr.mean(0,keepdims=True); yscl=ytr.std(0,keepdims=True)+1e-7
    X=torch.from_numpy((xtr-xm)/xscl)
    Y=torch.from_numpy((ytr-ym)/yscl)
    net=Net()
    opt=torch.optim.Adam(net.parameters(),lr=2e-3)
    gen=torch.Generator().manual_seed(seed+1000)
    n=X.shape[0]
    for step in range(STEPS):
        idx=torch.randint(0,n,(BATCH,),generator=gen)
        pred=net(X[idx])
        loss=((pred-Y[idx])**2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
        if step in (900,1200):
            for g in opt.param_groups: g['lr']*=0.35
    return net, (xm,xscl,ym,yscl), xs, Ss

def predict(net,norm,features):
    xm,xscl,ym,yscl=norm
    X=torch.from_numpy(((features.astype(np.float32)-xm)/xscl).astype(np.float32))
    with torch.no_grad(): y=net(X).numpy()
    return y*yscl+ym

def make_common_test_sets():
    # One fixed test set per deployment condition is shared by all trained networks.
    # This isolates training-seed variation from test-set sampling variation.
    rng=np.random.default_rng(TEST_SEED)
    f,mu,u = sample_data(rng,NTEST,0.5,2.0)
    fe,mue,ue = sample_data(rng,NTEST,2.5,4.0)
    return (f,mu,u),(fe,mue,ue)

def evaluate_seed(seed, common_tests):
    net,norm,xs,Ss=train_one(seed)
    (f,mu,u),(fe,mue,ue)=common_tests
    # The first three conditions use exactly the same 600 forcing/parameter pairs.
    full=np.concatenate([f@Ss.T,mu],axis=1)
    pred=predict(net,norm,full)
    e_id=rel_l2_on_grid(pred,u,64)
    e_out=rel_l2_on_grid(pred,u,256)
    # Input-sensor coarsening: only eight forcing sensors, linearly reconstructed at the 32 training locations.
    xc,Sc=sensor_matrix(NCOARSE)
    coarse=f@Sc.T
    recon=np.stack([np.interp(xs,xc,row) for row in coarse],axis=0)
    pred_c=predict(net,norm,np.concatenate([recon,mu],axis=1))
    e_in=rel_l2_on_grid(pred_c,u,64)
    # Parameter extrapolation uses one second fixed test set shared across all five networks.
    prede=predict(net,norm,np.concatenate([fe@Ss.T,mue],axis=1))
    e_ext=rel_l2_on_grid(prede,ue,64)
    return [np.median(e_id),np.median(e_out),np.median(e_in),np.median(e_ext)]

def main():
    t0=time.time()
    common_tests=make_common_test_sets()
    vals=np.array([evaluate_seed(s,common_tests) for s in SEEDS])
    labels=['parameter\ninterpolation','output-grid\nevaluation 64→256','input-sensor coarsening\n32→8 sensors','parameter\nextrapolation']
    med=np.median(vals,axis=0); lo=np.min(vals,axis=0); hi=np.max(vals,axis=0)
    fig,ax=plt.subplots(figsize=(7.5,3.96))
    x=np.arange(len(labels))
    ax.errorbar(x,med,yerr=np.vstack([med-lo,hi-med]),fmt='D',capsize=5,linewidth=1.5,label='median + min--max')
    for i in range(vals.shape[0]): ax.plot(x,vals[i],'o',markersize=3.5,alpha=0.55)
    ax.set_yscale('log')
    ax.set_xticks(x,labels)
    ax.set_ylabel(r'median relative $E_2^{\mathrm{rel}}$ error')
    ax.grid(True,axis='y',alpha=0.25)
    fig.tight_layout()
    for ext in ['pdf','png','eps']:
        fig.savefig(OUT/f'fig3_generalization_stress.{ext}',dpi=240)
    plt.close(fig)
    data={'seeds':SEEDS,'per_seed_median_relative_L2':vals.tolist(),'condition_median':med.tolist(),'condition_min':lo.tolist(),'condition_max':hi.tolist(),'runtime_s':time.time()-t0,
          'training':{'pde':'-u_xx + mu u = f','mu_train':[0.5,2.0],'mu_extrap':[2.5,4.0],'forcing_modes':K,'training_sensors':NS,'coarse_sensors':NCOARSE,'steps':STEPS,'batch':BATCH,'ntrain':NTRAIN,'ntest_per_condition':NTEST,'common_test_seed':TEST_SEED,'same_fixed_test_sets_across_training_seeds':True,'architecture':[NS+1,64,64,K],'activation':'tanh','optimizer':'Adam','initial_lr':2e-3,'lr_multiplier':0.35,'lr_drop_steps':[900,1200],'execution':'CPU; runtime not used as evidence'}}
    (OUT/'fig3_generalization_stress.json').write_text(json.dumps(data,indent=2))
    print(json.dumps(data,indent=2))

if __name__=='__main__': main()
