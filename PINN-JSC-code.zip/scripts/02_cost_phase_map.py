from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt

FIG_FONT = 11.2  # gives about 9 pt after full-width placement in the JSC smallextended text block
plt.rcParams.update({
    'font.size': FIG_FONT,
    'axes.labelsize': FIG_FONT,
    'xtick.labelsize': FIG_FONT,
    'ytick.labelsize': FIG_FONT,
    'legend.fontsize': FIG_FONT,
})
from matplotlib import colors, cm
OUT=Path(__file__).resolve().parents[1]/'figures'; OUT.mkdir(parents=True,exist_ok=True)

def truncated_cmap(name='viridis', minval=0.20, maxval=0.98, n=256):
    cmap=cm.get_cmap(name, n)
    return colors.LinearSegmentedColormap.from_list(f"trunc_{name}", cmap(np.linspace(minval,maxval,n)))

def main():
    beta=np.linspace(0,0.98,300)
    alphas=[0.1,1,10,100,1000]
    fig,axs=plt.subplots(1,2,figsize=(7.5,3.15))
    ax=axs[0]
    styles=['-','--','-.',':',(0,(5,1,1,1))]
    for a,ls in zip(alphas,styles):
        ax.plot(beta,a/(1-beta),linestyle=ls,label=fr'$\alpha={a:g}$')
    ax.set_yscale('log')
    ax.set_xlabel(r'online-cost ratio $\beta=(C_{\rm inf}+C_{\rm adapt})/C_{\rm solve}$')
    ax.set_ylabel(r'break-even queries $Q_\star$')
    ax.text(0.98,0.98,'(a)',transform=ax.transAxes,va='top',ha='right',fontweight='bold')
    ax.legend(fontsize=FIG_FONT,ncol=2)
    ax.grid(True,alpha=0.25)

    B=np.linspace(0,1.2,241)
    A=np.logspace(-1,3,241)
    BB,AA=np.meshgrid(B,A)
    Q=np.where(BB<1,AA/(1-BB),np.nan)
    ax=axs[1]
    cmap=truncated_cmap('viridis',0.20,0.98)
    norm=colors.LogNorm(vmin=1e-1,vmax=1e5)
    cf=ax.contourf(B,A,Q,levels=np.logspace(-1,5,13),cmap=cmap,norm=norm,extend='max')
    # Light contour overlays for readability.
    contour_levels=[1,10,100,1000,10000]
    cs=ax.contour(B,A,Q,levels=contour_levels,colors='white',linewidths=0.45,alpha=0.45)
    ax.clabel(cs, fmt={lvl:fr'$10^{{{int(np.log10(lvl))}}}$' if lvl!=1 else '1' for lvl in contour_levels}, fontsize=FIG_FONT, inline=True)
    ax.axvline(1,linestyle='--',linewidth=1,color='tab:blue')
    ax.axvspan(1,1.2,color='0.92',zorder=0)
    ax.set_yscale('log')
    ax.set_xlabel(r'online-cost ratio $\beta$')
    ax.set_ylabel(r'offline-cost ratio $\alpha$')
    ax.text(0.02,0.98,'(b)',transform=ax.transAxes,va='top',fontweight='bold')
    cbar=fig.colorbar(cf,ax=ax,pad=0.02)
    cbar.set_label(r'$Q_\star$')
    ax.text(1.03,20,'no break-even',rotation=90,va='center',fontsize=FIG_FONT)
    fig.tight_layout()
    for ext in ['pdf','png','eps']:
        fig.savefig(OUT/f'fig2_break_even_phase.{ext}',dpi=240)
    plt.close(fig)
    data={'alphas':alphas,'interpretation':'Q*=alpha/(1-beta) for alpha>0,beta<1; beta>=1 has no break-even',
          'plotting_note':'panel (b) uses a lightened log-scaled sequential colormap with contour overlays for readability'}
    (OUT/'fig2_break_even_phase.json').write_text(json.dumps(data,indent=2))
    print(json.dumps(data,indent=2))
if __name__=='__main__':
    main()
