from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt

FIG_FONT = 11.2  # gives about 9 pt after full-width placement in the JSC smallextended text block
plt.rcParams.update({
    'font.size': FIG_FONT,
    'axes.labelsize': FIG_FONT,
    'xtick.labelsize': FIG_FONT,
    'ytick.labelsize': FIG_FONT,
    'legend.fontsize': FIG_FONT,
})
from matplotlib import colors
OUT=Path(__file__).resolve().parents[1]/'figures'; OUT.mkdir(parents=True,exist_ok=True)
N=80; NU=0.1; TARGET_G1=0.995

def main():
    h=1/(N+1)
    k=np.arange(1,N+1)
    lam=-4/h**2*np.sin(k*np.pi/(2*(N+1)))**2
    dt=np.log(TARGET_G1)/(NU*lam[0])
    g=np.exp(NU*lam*dt)
    epscrit=1-g
    eps=np.linspace(0,0.08,321)
    rho=np.empty((N,len(eps)))
    g1=g[0]
    for i in range(N):
        rho[i]=np.maximum(g1, g[i]+eps)
    epss=np.linspace(1e-5,0.009,300)
    horizons=[]
    thr=0.1
    for e in epss:
        ratio=1+e/g1
        n=np.log(1+thr)/np.log(ratio)
        horizons.append(np.ceil(n))
    horizons=np.array(horizons)

    fig,axs=plt.subplots(1,3,figsize=(7.5,2.35))
    ax=axs[0]
    norm=colors.TwoSlopeNorm(vmin=0.98,vcenter=1.0,vmax=1.08)
    im=ax.imshow(rho,origin='lower',aspect='auto',extent=[eps[0],eps[-1],1,N],
                 cmap='RdYlBu_r',norm=norm)
    ax.contour(eps,np.arange(1,N+1),rho,levels=[1.0],colors='k',linewidths=1.2)
    ax.set_xlabel(r'perturbation norm $\varepsilon$')
    ax.set_ylabel('perturbed eigenmode index')
    ax.text(0.02,0.98,'(a)',transform=ax.transAxes,va='top',fontweight='bold')
    cb=fig.colorbar(im,ax=ax,pad=0.02)
    cb.set_label(r'$\rho(\widehat{\mathbf{A}})$')
    cb.set_ticks([0.98,1.00,1.02,1.04,1.06,1.08])

    ax=axs[1]
    ax.plot(k,epscrit,'o-',markersize=2)
    ax.set_yscale('log')
    ax.set_xlabel('eigenmode index')
    ax.set_ylabel(r'critical $\varepsilon_c=1-\sigma_p$')
    ax.text(0.02,0.98,'(b)',transform=ax.transAxes,va='top',fontweight='bold')
    ax.grid(True,alpha=0.25)

    ax=axs[2]
    ax.plot(epss,horizons,label=r'$n_{0.1}$')
    ax.axvline(epscrit[0],linestyle='--',linewidth=1,label=fr'$\varepsilon_c={epscrit[0]:.4f}$')
    ax.set_yscale('log')
    ax.set_xlabel(r'$\varepsilon$ on slowest mode')
    ax.set_ylabel('steps to 10% relative error')
    ax.text(0.02,0.98,'(c)',transform=ax.transAxes,va='top',fontweight='bold')
    ax.legend(fontsize=FIG_FONT)
    ax.grid(True,alpha=0.25)
    fig.tight_layout()
    for ext in ['pdf','png','eps']:
        fig.savefig(OUT/f'fig4_rollout_stability_map.{ext}',dpi=240)
    plt.close(fig)
    data={'N':N,'nu':NU,'dt':float(dt),'reference_slowest_amplification':float(g1),'critical_epsilon_slowest':float(epscrit[0]),
          'critical_epsilon_modes_1_10':epscrit[:10].tolist(),'horizon_threshold':thr,'horizon_formula':'ceil(log(1+threshold)/log(1+epsilon/sigma_1))','horizon_capped':False,
          'plotting_note':'panel (a) uses a diverging colormap centered at rho=1 to emphasize the stability boundary'}
    (OUT/'fig4_rollout_stability_map.json').write_text(json.dumps(data,indent=2))
    print(json.dumps(data,indent=2))
if __name__=='__main__':
    main()
