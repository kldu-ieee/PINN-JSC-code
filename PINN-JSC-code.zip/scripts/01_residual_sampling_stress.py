from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt

FIG_FONT = 11.2  # gives about 9 pt after full-width placement in the JSC smallextended text block
plt.rcParams.update({
    'font.size': FIG_FONT,
    'axes.labelsize': FIG_FONT,
    'xtick.labelsize': FIG_FONT,
    'ytick.labelsize': FIG_FONT,
    'legend.fontsize': FIG_FONT,
})

OUT=Path(__file__).resolve().parents[1]/'figures'; OUT.mkdir(parents=True,exist_ok=True)
M=8
SEEDS=list(range(20))

def sinm(x): return np.sin(M*np.pi*x)

def train_scalar(seed, rule, steps=200, lr=0.15):
    rng=np.random.default_rng(seed)
    a=float(rng.normal(0.0,0.5))
    h=1.0/M
    fixed=np.arange(1,M)/M
    if rule=='jittered':
        x=np.clip(fixed+rng.normal(0,0.08*h,size=fixed.size),1e-6,1-1e-6)
    for _ in range(steps):
        if rule=='fixed': x=fixed
        elif rule=='resampled': x=rng.uniform(0,1,size=M-1)
        s=sinm(x)
        # normalized PDE residual: (a-1) sin(m pi x)
        grad=2*(a-1)*np.mean(s*s)
        a-=lr*grad
    # state error ||(a-1)sin||_L2
    return a, abs(a-1)/np.sqrt(2)

def main():
    rng=np.random.default_rng(1234)
    x=np.linspace(0,1,1200)
    a=0.05
    u=a*sinm(x)
    r=a*(M*np.pi)**2*sinm(x)
    xc=np.arange(1,M)/M

    ratios=np.array([0.5,1,2,4,8,16.0])
    trials=600
    est=[]
    # empirical RMS / true RMS for random collocation; true RMS = 1/sqrt(2) for sin over [0,1]
    for q in ratios:
        n=max(2,int(round(q*M)))
        vals=[]
        for _ in range(trials):
            xr=rng.uniform(0,1,n)
            vals.append(np.sqrt(np.mean(sinm(xr)**2))/(1/np.sqrt(2)))
        est.append(vals)
    est=np.array(est)

    train={rule:np.array([train_scalar(s,rule)[1] for s in SEEDS]) for rule in ['fixed','jittered','resampled']}

    fig,axs=plt.subplots(1,3,figsize=(7.5,2.26),gridspec_kw={'width_ratios':[0.85,1.15,1.10]})
    ax=axs[0]
    ax.plot(x,u,label=r'$\widehat u_m$')
    ax.axhline(0,linestyle='--',linewidth=1,label='exact $u$')
    ax.plot(xc,np.zeros_like(xc),'o',markersize=4,label='aliased collocation')
    ax.set_xlabel('$x$'); ax.set_ylabel('state'); ax.text(0.02,0.98,'(a)',transform=ax.transAxes,va='top',fontweight='bold'); ax.legend(fontsize=FIG_FONT)

    ax=axs[1]
    med=np.median(est,axis=1); lo=np.percentile(est,5,axis=1); hi=np.percentile(est,95,axis=1)
    ax.errorbar(ratios,med,yerr=np.vstack([med-lo,hi-med]),fmt='o-',capsize=3)
    ax.axhline(1,linestyle='--',linewidth=1)
    ax.set_xscale('log',base=2); ax.set_xlabel('random samples per residual\nwavelength $N_r/m$')
    ax.set_ylabel('empirical RMS /\ncontinuous RMS'); ax.text(0.02,0.98,'(b)',transform=ax.transAxes,va='top',fontweight='bold')
    ax.grid(True,alpha=0.25)

    ax=axs[2]
    xpos=np.arange(3)
    data=[train['fixed'],train['jittered'],train['resampled']]
    bp=ax.boxplot(data,positions=xpos,widths=0.5,showfliers=True)
    ax.set_yscale('log'); ax.set_xticks(xpos,['aliased','jittered','resampled'], rotation=25, ha='right'); ax.set_xlabel('collocation rule')
    ax.set_ylabel(r'final field error $E_2(u_a,u)$')
    ax.text(0.02,0.98,'(c)',transform=ax.transAxes,va='top',fontweight='bold')
    ax.grid(True,axis='y',alpha=0.25)
    fig.tight_layout()
    for ext in ['pdf','png','eps']: fig.savefig(OUT/f'fig1_residual_sampling_stress.{ext}',dpi=240)
    plt.close(fig)

    result={'m':M,'a_demo':a,'random_sampling_ratios':ratios.tolist(),
            'sampling_ratio_median':med.tolist(),'sampling_ratio_p05':lo.tolist(),'sampling_ratio_p95':hi.tolist(),
            'training_final_state_error':{k:v.tolist() for k,v in train.items()},
            'training_error_median':{k:float(np.median(v)) for k,v in train.items()},'seeds':SEEDS}
    (OUT/'fig1_residual_sampling_stress.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
