from pathlib import Path
import json
import numpy as np
import matplotlib.pyplot as plt

FIG_FONT = 11.2  # gives about 9 pt after full-width placement in the JSC smallextended text block
plt.rcParams.update({
    'font.size': FIG_FONT,
    'axes.labelsize': FIG_FONT,
    'xtick.labelsize': FIG_FONT,
    'ytick.labelsize': FIG_FONT,
    'legend.fontsize': FIG_FONT,
})
OUT=Path(__file__).resolve().parents[1]/'figures'; OUT.mkdir(parents=True,exist_ok=True)
EPS=5e-4

def eigs_poisson(N):
    h=1/(N+1)
    j=np.arange(1,N+1)
    lam=4/h**2*np.sin(j*np.pi/(2*(N+1)))**2
    return h,lam

def main():
    Ns=np.arange(10,201,2)
    hs=[]; ecrit=[]; rlow=[]; rhigh=[]
    for N in Ns:
        h,lam=eigs_poisson(N); hs.append(h); ecrit.append(1/lam[-1]); rlow.append(EPS*lam[0]); rhigh.append(EPS*lam[-1])
    hs=np.array(hs); ecrit=np.array(ecrit); rlow=np.array(rlow); rhigh=np.array(rhigh)
    fig,axs=plt.subplots(1,3,figsize=(7.5,2.35))
    ax=axs[0]
    ax.loglog(hs,ecrit,'o-',markersize=2,label=r'$1/\lambda_{\max}(\mathbf{A}_h)$')
    ax.loglog(hs,hs**2/4,'--',label=r'$h^2/4$ asymptote')
    ax.set_xlabel('mesh spacing $h$'); ax.set_ylabel(r'critical component error $\varepsilon_c$'); ax.text(0.98,0.98,'(a)',transform=ax.transAxes,va='top',ha='right',fontweight='bold'); ax.legend(fontsize=FIG_FONT,loc='lower right'); ax.grid(True,which='both',alpha=0.25)

    ax=axs[1]
    ax.plot(Ns,rlow,linestyle='-',marker='o',markevery=12,markersize=2.5,label='low-mode perturbation')
    ax.plot(Ns,rhigh,linestyle='--',marker='s',markevery=12,markersize=2.5,label='high-mode perturbation')
    ax.axhline(1,linestyle='--',linewidth=1,label='stability boundary')
    ax.set_yscale('log'); ax.set_xlabel('interior points $N$'); ax.set_ylabel(r'$\rho(\mathbf{I}-\widehat{\mathbf{B}}\mathbf{A}_h)$')
    ax.text(0.02,0.98,'(b)',transform=ax.transAxes,va='top',fontweight='bold')
    ax.text(150, rlow[np.searchsorted(Ns,150)]*1.35, 'low mode', ha='right', va='bottom')
    ax.text(150, rhigh[np.searchsorted(Ns,150)]/1.35, 'high mode', ha='right', va='top')
    ax.text(196, 1.15, r'$\rho=1$', ha='right', va='bottom')
    ax.grid(True,alpha=0.25)

    ax=axs[2]
    its=np.arange(0,11)
    chosen=[20,40,80]
    styles=['-','--','-.']; markers=['o','s','^']
    for N,ls,mk in zip(chosen,styles,markers):
        h,lam=eigs_poisson(N); rho=EPS*lam[-1]
        # residual in the aligned high-frequency mode scales as rho^k
        rr=rho**its
        ax.plot(its,rr,linestyle=ls,marker=mk,markersize=3,label=fr'$N={N}$, $\rho={rho:.2f}$')
    ax.set_yscale('log'); ax.set_xlabel('iteration'); ax.set_ylabel('relative residual'); ax.text(0.02,0.98,'(c)',transform=ax.transAxes,va='top',fontweight='bold')
    ax.set_xlim(0,13.8)
    for N,ls,mk in zip(chosen,styles,markers):
        h,lam=eigs_poisson(N); rho=EPS*lam[-1]
        y=rho**its[-1]
        ax.text(10.4, y, fr'$N={N}$, $\rho={rho:.2f}$', va='center', ha='left')
    ax.grid(True,alpha=0.25)
    fig.tight_layout()
    for ext in ['pdf','png','eps']: fig.savefig(OUT/f'fig5_hybrid_mesh_stability.{ext}',dpi=240)
    plt.close(fig)
    # slope of log epscrit vs log h for fine half
    slope=np.polyfit(np.log(hs[len(hs)//2:]),np.log(ecrit[len(ecrit)//2:]),1)[0]
    data={'epsilon_fixed':EPS,'critical_error_scaling_slope':float(slope),'selected':{},'asymptotic':'epsilon_c ~ h^2/4'}
    for N in [20,40,60,80]:
        h,lam=eigs_poisson(N); data['selected'][str(N)]={'h':float(h),'rho_low':float(EPS*lam[0]),'rho_high':float(EPS*lam[-1]),'epsilon_critical_high':float(1/lam[-1])}
    (OUT/'fig5_hybrid_mesh_stability.json').write_text(json.dumps(data,indent=2)); print(json.dumps(data,indent=2))
if __name__=='__main__': main()
